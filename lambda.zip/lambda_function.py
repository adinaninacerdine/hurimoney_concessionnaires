import json
import boto3
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
customer_table = dynamodb.Table('hurimoney-customers')

def handler(event, context):
    """
    Lambda function to process HuriMoney B2C transactions from Kinesis
    """
    logger.info(f"Processing {len(event['Records'])} records")
    
    for record in event['Records']:
        try:
            # Decode Kinesis data
            payload = json.loads(record['kinesis']['data'])
            logger.info(f"Processing transaction: {payload}")
            
            # Extract transaction data
            customer_phone = payload.get('customer_phone')
            transaction_amount = payload.get('amount', 0)
            transaction_type = payload.get('transaction_type', 'unknown')
            timestamp = datetime.utcnow().isoformat()
            
            # Update customer record in DynamoDB
            if customer_phone:
                response = customer_table.update_item(
                    Key={'customer_phone': customer_phone},
                    UpdateExpression='SET last_transaction = :timestamp, total_amount = if_not_exists(total_amount, :zero) + :amount, transaction_count = if_not_exists(transaction_count, :zero) + :one',
                    ExpressionAttributeValues={
                        ':timestamp': timestamp,
                        ':amount': transaction_amount,
                        ':zero': 0,
                        ':one': 1
                    },
                    ReturnValues='UPDATED_NEW'
                )
                logger.info(f"Updated customer {customer_phone}: {response}")
            
        except Exception as e:
            logger.error(f"Error processing record: {str(e)}")
            # Continue processing other records
    
    return {
        'statusCode': 200,
        'body': json.dumps(f'Successfully processed {len(event["Records"])} records')
    }