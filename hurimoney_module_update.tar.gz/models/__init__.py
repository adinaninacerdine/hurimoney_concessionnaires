from . import concessionnaire
from . import kit
from . import transaction
from . import res_config_settings
from . import res_partner